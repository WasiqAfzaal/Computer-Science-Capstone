package com.WasiqAfzaal.Mobile2App;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AddEditWeightActivity extends AppCompatActivity {

    private EditText editDate, editWeight;
    private DatabaseHelper db;

    private long weightId = -1;

    private static final String PREFS = "wt_prefs";
    private static final String KEY_USER_ID = "logged_in_user_id";

    private static final int SMS_PERMISSION_CODE = 100;

    private long userId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_edit_weight);

        db = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        userId = prefs.getLong(KEY_USER_ID, -1);

        if (userId == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        Button buttonSave = findViewById(R.id.buttonSave);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("weightId")) {
            weightId = intent.getLongExtra("weightId", -1);
            String date = intent.getStringExtra("date");
            double weight = intent.getDoubleExtra("weight", 0);

            if (date != null) editDate.setText(date);
            editWeight.setText(String.valueOf(weight));
        }

        buttonSave.setOnClickListener(v -> save());
        buttonCancel.setOnClickListener(v -> finish());
    }

    private void save() {
        String date = editDate.getText().toString().trim();
        String weightStr = editWeight.getText().toString().trim();

        if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weightStr)) {
            Toast.makeText(this, "Enter date and weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        double weightVal = Double.parseDouble(weightStr);

        if (weightId == -1) {
            db.addWeight(userId, date, weightVal);
        } else {
            db.updateWeight(weightId, date, weightVal);
        }

        checkGoalAndSendSMS(weightVal);

        finish();
    }

    private void checkGoalAndSendSMS(double weightVal) {
        double goalWeight = 170.0;

        if (weightVal <= goalWeight) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                sendSMS("5551234567",
                        "Congratulations! You reached your goal weight of " + goalWeight + " lbs!");

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            }
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal SMS sent!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                sendSMS("5551234567",
                        "Congratulations! You reached your goal weight!");
            } else {
                Toast.makeText(this,
                        "SMS permission denied. App will continue without SMS.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
