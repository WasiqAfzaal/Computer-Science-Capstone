package com.WasiqAfzaal.Mobile2App;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private DatabaseHelper db;

    // SharedPreferences keys
    private static final String PREFS = "wt_prefs";
    private static final String KEY_USER_ID = "logged_in_user_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);

        // If user already logged in, skip login screen
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        long savedUserId = prefs.getLong(KEY_USER_ID, -1);

        if (savedUserId != -1) {
            openWeightLog();
            return;
        }

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> loginUser());
        buttonCreateAccount.setOnClickListener(v -> createAccount());
    }

    private void loginUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        long userId = db.validateLogin(username, password);

        if (userId != -1) {
            saveUserSession(userId);
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();
            openWeightLog();
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter username and password to create an account.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.usernameExists(username)) {
            Toast.makeText(this, "Username already exists. Please log in.", Toast.LENGTH_SHORT).show();
            return;
        }

        long newUserId = db.createUser(username, password);

        if (newUserId != -1) {
            saveUserSession(newUserId);
            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();
            openWeightLog();
        } else {
            Toast.makeText(this, "Account creation failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveUserSession(long userId) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putLong(KEY_USER_ID, userId).apply();
    }

    private void openWeightLog() {
        Intent intent = new Intent(LoginActivity.this, WeightLogActivity.class);
        startActivity(intent);
        finish(); // prevents back button returning to login
    }
}
